﻿BIMSeePro 3.1.0

Portable build - there is no installer. Unzip and run bimsee.exe.

This package contains the main program and the ifcloader plugin only.
Other plugins (for example 3D Tiles) are installed from the Plugin Manager dialog.
